<h2><strong>CCoin Repository (Version 2.1.7)</strong></h2>
<p>More information at crypto.rocket.chat</p>
<h3><strong>Coin specs:</strong></h3>
<p><strong><span style="color: #800080;"><em>Algo:</em></span></strong></p>
<ul>
<li>Quark</li>
</ul>
<p><strong><span style="color: #800080;"><em>PoW Block Reward:</em></span></strong></p>
<ul>
<li>[block# 2-151200] 250 CCC [block# 151201-259200] 50 CCC</li>
</ul>
<p><strong><span style="color: #800080;"><em>PoS Block Reward:</em></span></strong></p>
<ul>
<li>[block# 259201-Infinite] Variable based on SeeSaw Reward Mechanism</li>
</ul>
<p><strong><span style="color: #800080;"><em>Block Time:</em></span></strong></p>
<ul>
<li>60 Seconds with Retargeting every Block</li>
</ul>
<p><strong><span style="color: #800080;"><em>Max Coin Supply:</em></span></strong></p>
<ul>
<li>PoW Phase: 43,199,500</li>
</ul>
<p><strong><span style="color: #800080;"><em>Max Coin Supply:</em></span></strong></p>
<ul>
<li>PoS Phase: Infinte</li>
</ul>
<p><strong><span style="color: #800080;"><em>PoW Phase 1:</em></span></strong></p>
<ul>
<li>[block# 1] 60k Premine for creation of 6 Masternodes for the functioning of the network.</li>
</ul>
<p><strong><span style="color: #800080;"><em>Pre-mine:</em></span></strong></p>

<p><strong><span style="color: #800080;"><em>PoW Rewards Breakdown:</em></span></strong></p>
<ul>
<li>[block&rsquo;s &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;2-432000] 20% MN (50 CCC) &nbsp; &nbsp;/ 80% MINER (200 CCC)</li>
<li>[block&rsquo;s &nbsp; 43201-151200] 20% MN (50 CCC) &nbsp; &nbsp;/ 70% MINER (200 CCC) &nbsp;/ 10% Available to the budget system (25 CCC)</li>
<li>[block&rsquo;s 151201-259200] 45% MN (22.5 CCC) / 45% MINER (22.5 CCC) / 10% Available to the budget system ( &nbsp;5 CCC)</li>
</ul>
<p><strong><span style="color: #800080;"><em>PoS Rewards Breakdown:</em></span></strong></p>
<ul>
<li>PoS Phase 1: [blocks 259201-302399] 50 CCC (90% distributed to staker and masternode - 10% available to budget system)</li>
<li>PoS Phase 2: [blocks 302400-345599] 45 CCC (90% distributed to staker and masternode - 10% available to budget system)</li>
<li>PoS Phase 3: [blocks 345600-388799] 40 CCC (90% distributed to staker and masternode - 10% available to budget system)</li>
<li>PoS Phase 4: [blocks 388800-431999] 35 CCC (90% distributed to staker and masternode - 10% available to budget system)</li>
<li>PoS Phase 5: [blocks 432000-475199] 30 CCC (90% distributed to staker and masternode - 10% available to budget system)</li>
<li>PoS Phase 6: [blocks 475200-518399] 25 CCC (90% distributed to staker and masternode - 10% available to budget system)</li>
<li>PoS Phase 7: [blocks 518400-561599] 20 CCC (90% distributed to staker and masternode - 10% available to budget system)</li>
<li>PoS Phase 8: [blocks 561600-604799] 15 CCC (90% distributed to staker and masternode - 10% available to budget system)</li>
<li>PoS Phase 9: [blocks 604800-647999] 10 CCC (90% distributed to staker and masternode - 10% available to budget system)</li>
<li>PoS Phase X: [blocks 648000-Infinite] &nbsp; 5 CCC (90% distributed to staker and masternode - 10% available to budget system)</li>
</ul>
<p>&nbsp;</p>
<p>+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++</p>
<p>&nbsp;</p>
<p>CCoin is a cutting edge cryptocurrency, with many features not available in most other cryptocurrencies.</p>
<p>Anonymized transactions using coin mixing technology, we call it <em>Obfuscation</em>.</p>
<p>Fast transactions featuring guaranteed zero confirmation transactions, we call it <em>SwiftTX</em>.</p>
<p>Decentralized blockchain voting providing for consensus based advancement of the current Masternode technology used to secure the network and provide the above features, each Masternode is secured with collateral of 10K CCC</p>
