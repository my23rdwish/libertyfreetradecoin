Sample configuration files for:

SystemD: clonecoind.service
Upstart: clonecoind.conf
OpenRC:  clonecoind.openrc
         clonecoind.openrcconf
CentOS:  clonecoind.init

have been made available to assist packagers in creating node packages here.

See doc/init.md for more information.
